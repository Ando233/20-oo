class Ellipse extends Shape{
    @Override
    public double calcArea() {
        return Math.PI*a*b;
    }
}
