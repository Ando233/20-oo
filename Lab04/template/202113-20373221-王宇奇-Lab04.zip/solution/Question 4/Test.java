public class Test {
    public static void main(String[] args) {
        Rectangle a = new Rectangle();
        a.setA(2);
        a.setB(4);
        System.out.println(a.calcArea());
        Rhombus b = new Rhombus();
        b.setA(-2);
        b.setB(7);
        System.out.println(b.calcArea());
    }
}
