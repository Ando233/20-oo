class Rhombus extends Shape{
    @Override
    public double calcArea() {
        return a*b/2;
    }
}
