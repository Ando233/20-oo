class Rectangle extends Shape{

    @Override
    public double calcArea() {
        return a*b;
    }
}
