public class Vehical {
    protected int wheelNum;

    public Vehical(int a){
        wheelNum = a;
    }

}
