public class Ink extends File{
    File target;
    String name;

    public void open(){
        target.open();
    }
}
